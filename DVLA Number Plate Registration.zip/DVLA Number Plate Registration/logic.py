from models import Application
from utils import generate_accra_plate

class RegistrationManager:
    def __init__(self):
        self.applications = []

    def submit(self, user, vehicle):
        app_id = len(self.applications) + 1
        new_app = Application(app_id, user.user_id, vehicle.vin)
        self.applications.append(new_app)
        return new_app
    
    def approve(self, app_id):
        for app in self.applications:
            if app.app_id == app_id:
                app.status = "Approved"
                app.plate_number = generate_accra_plate(app_id)
                return True
        return False
