class User:
    def __init__(self, user_id, name, license_no):
        self.user_id = user_id
        self.name = name
        self.license_no = license_no

class Vehicle:
    def __init__(self, vin, make, model):
        self.vin = vin
        self.make =make
        self.model = model

class Application:
    def __init__(self, app_id, user_id, vin):
        self.app_id = app_id
        self.user_id = user_id
        self.vin = vin
        self.status = "Pending"
        self.plate_number = None