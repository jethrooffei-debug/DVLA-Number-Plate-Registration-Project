import random

def generate_accra_plate(app_id):
    random_digits = random.randint(1000, 9999)
    return f"GA {random_digits} - 26"

def validate_vin(vin):
    return len(vin) == 17